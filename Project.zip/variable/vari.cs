﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace variable
{
    public class vari
    {
        public string name { get; set; }
        public int id { get; set; }
        public string password { get; set; }
        public string position { get; set; }
        public string address { get; set; }
        public string mobile { get; set; }
        public string uname { get; set; }
        public string DOB { get; set; }
        public string fname { get; set; }
        public string lname { get; set; }
        public string gender{ get; set; }
        public string Type{ get; set; }
        public string Price { get; set; }
        public string No_of_bed { get; set; }
        public string Level{ get; set; }
        public string Extrabed{ get; set; }
        public string Department{ get; set; }
        public string salary { get; set; }
        public string available{ get; set; }
        public string Booking { get; set; }
        public string gid { get; set; }
        public string Payment { get; set; }
        public string Status { get; set; }
        public string Service { get; set; }
        public string Description { get; set; }
        public string Room_id { get; set; }
        public string Quantity { get; set; }





    }
}
