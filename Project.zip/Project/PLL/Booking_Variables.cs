﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.PLL
{
    class Booking_Variables
    {

        public int Id { get; set; }
        public string G_id { get; set; }
        public string Price { get; set; }
        public string Payment { get; set; }
        public string Service { get; set; }
        public string Status { get; set; }
        public string S_id { get; set; }
    }
}
