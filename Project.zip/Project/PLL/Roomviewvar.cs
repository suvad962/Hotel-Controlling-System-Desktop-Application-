﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.PLL
{
    class Roomviewvar
    {
        public int Id { get; set; }
        public string Type { get; set; }
        public string Price { get; set; }
        public string NOB { get; set; }
        public string Floor { get; set; }
        public string Extabed { get; set; }
        public string Booking { get; set; }
       // public string G_id { get; set; }

    }
}
