﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.PLL
{
    class HotelRoom
    {
        public int Id { get; set; }
        public string Room_Type { get; set; }
        public string Room_Price { get; set; }
        public string No_bed { get; set; }
        public string Room_Floor { get; set; }
        public string Extrabed { get; set; }
        public string booking { get; set; }

    }
}
