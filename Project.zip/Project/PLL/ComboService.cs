﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.PLL
{
    class ComboService
    {

        public string Service_Name { get; set; }


    }
}
